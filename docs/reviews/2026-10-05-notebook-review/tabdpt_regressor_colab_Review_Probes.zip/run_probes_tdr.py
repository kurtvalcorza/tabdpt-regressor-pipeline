"""TDR / TDRA probes: exec the TabDPT regressor notebooks' own cells torch-free.

usage: python run_probes_tdr.py <repo checkout> <out dir>
"""
from __future__ import annotations
import hashlib, io, json, os, shutil, sys, tempfile, types
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
import harness as H

REPO = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]).resolve(); OUT.mkdir(parents=True, exist_ok=True)
E2E = REPO / "tutorials/tabdpt_regressor_colab.ipynb"
AI = REPO / "tutorials/tabdpt_regressor_artifact_inference_colab.ipynb"
RESULTS = {}

# ---------------- stand-in upstream estimator ----------------
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

class StandInTabDPTRegressor:
    """scikit-learn stand-in with TabDPTRegressor's fit/predict surface (NOT the model)."""
    def __init__(self, **kw):
        self.kw = kw; self.device = "cpu"; self.max_features = 100; self.feature_reduction = "pca"
        self.normalizer = "standard"; self.missing_indicators = False; self.V = None
        self.imputer = None; self.scaler = None; self._reg = None
    def fit(self, X, y):
        self.imputer = SimpleImputer(strategy="mean").fit(X)
        self.scaler = StandardScaler().fit(self.imputer.transform(X))
        self.X_train = self.scaler.transform(self.imputer.transform(X)); self.y_train = np.asarray(y, dtype=float)
        self.n_instances, self.n_features = self.X_train.shape
        if self.n_features > self.max_features:
            _, _, vt = np.linalg.svd(self.X_train, full_matrices=False); self.V = vt[: self.max_features].T
        self._reg = None; return self
    def _proj(self, Z):
        V = self.V
        if V is None: return Z
        V = getattr(V, "data", V); return Z @ np.asarray(V)
    def predict(self, X, **kw):
        if self._reg is None:
            self._reg = Ridge(alpha=1.0).fit(self._proj(self.X_train), self.y_train)
        Z = self.scaler.transform(self.imputer.transform(X))
        return self._reg.predict(self._proj(Z))

tabdpt = types.ModuleType("tabdpt"); tabdpt.TabDPTRegressor = StandInTabDPTRegressor
sys.modules["tabdpt"] = tabdpt
H.install_stub_modules({"tabdpt": "stand-in"})

E2E_CELLS, e2e_nb = H.code_cells(E2E)
AI_CELLS, ai_nb = H.code_cells(AI)
CARRIED = [5, 7, 9]

def fresh_ns(cells, workdir):
    os.chdir(workdir)
    mod = types.ModuleType("__nbprobe__"); sys.modules["__nbprobe__"] = mod; ns = mod.__dict__
    import importlib, platform, subprocess
    ns.update(importlib=importlib, platform=platform, os=os, sys=sys, subprocess=subprocess,
              torch=sys.modules["torch"], numpy=np, pandas=pd, sklearn=__import__("sklearn"),
              )
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"  # the notebook's own skip-install switch
    steps = [H.run_cell(ns, cells[i], i) for i in [3] + CARRIED]
    os.environ.pop("DIMER_NOTEBOOK_CI_PREINSTALLED")
    assert all(s["ok"] for s in steps), steps
    # Section 3 stand-in: the Hub is unreachable, so the weight file is a dummy whose digest replaces
    # TABDPT_WEIGHT_SHA256 in this namespace only.
    wd = Path(workdir) / "weights"; wd.mkdir(exist_ok=True); w = wd / "tabdpt1_2.safetensors"
    w.write_bytes(b"stand-in weights"); ns["TABDPT_WEIGHT_SHA256"] = H.sha256(w)
    ns["pipe"] = ns["TabDPTRegressionPipeline"](model_weight_path=w, compile_model=False, use_flash=False, seed=42)
    return ns

def set_form(src, name, value):
    lines = src.split("\n")
    for k, line in enumerate(lines):
        if line.startswith(f"{name} = "):
            comment = line[line.index("#"):] if "#" in line else ""
            lines[k] = f"{name} = {value!r}  {comment}"; return "\n".join(lines)
    raise KeyError(f"form field {name} not found")

# ---------------- P1: E2E default path through the notebook's own cells ----------------
def e2e_run(workdir, byod=None, categorical=None, stop_after=None):
    colab = H.Colab()
    ns = fresh_ns(E2E_CELLS, workdir)
    steps = []
    for i in [13, 15, 17, 19, 21, 23]:
        src = E2E_CELLS[i]
        if i == 13 and byod is not None:
            src = set_form(src, "USE_BYOD", True)
            if categorical is not None:
                src = set_form(src, "CATEGORICAL_COLUMNS", categorical)
            colab.queue.append(byod)
        s = H.run_cell(ns, src, i); steps.append(s)
        if not s["ok"] or (stop_after is not None and i == stop_after):
            break
    H.Colab.remove()
    return ns, steps

wd = Path(tempfile.mkdtemp(prefix="tdr_p1_"))
ns, steps = e2e_run(wd)
p1 = {"steps": [{k: v for k, v in s.items() if k != "stdout_tail"} | {"ok": s["ok"]} for s in steps]}
if all(s["ok"] for s in steps):
    p1.update(sample_csv_sha256=ns["sample_sha256"], split={"train": len(ns["train"]), "holdout": len(ns["test"])},
              train_target_mean=float(ns["train"]["target"].mean()),
              training_mean_baseline=ns["baseline"], input_manifest_findings=ns["input_manifest"]["findings"],
              outputs=sorted(os.listdir(wd / "outputs")), artifact_files=sorted(os.listdir(wd / "outputs/artifact")),
              stand_in_metrics_not_model_evidence=ns["metrics"],
              new_rows_index=list(map(int, ns["new_rows"].index)),
              new_rows_in_holdout=bool(set(ns["new_rows"].index) <= set(ns["test"].index)))
RESULTS["P1_e2e_default_standin"] = p1
E2E_WD = wd

# ---------------- P2: non-neural baselines on the notebook's own split ----------------
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
train, test = ns["train"], ns["test"]
Xtr, Xte = train.drop(columns="target"), test.drop(columns="target"); ytr, yte = train["target"], test["target"]
def m3(y, p): return {"mae": round(float(mean_absolute_error(y, p)), 3), "rmse": round(float(np.sqrt(mean_squared_error(y, p))), 3), "r2": round(float(r2_score(y, p)), 4)}
p2 = {"split": "the notebook's own seeded random 80/20 (random_state=42)", "holdout_rows": len(test), "target_sd_holdout": round(float(yte.std()), 3), "models": {}}
p2["models"]["training_mean"] = m3(yte, np.full(len(yte), ytr.mean()))
for name, m in {"linear_regression": LinearRegression(), "ridge(std, alpha 1)": make_pipeline(StandardScaler(), Ridge(1.0)),
                "knn15(std)": make_pipeline(StandardScaler(), KNeighborsRegressor(15)), "random_forest(500, seed 0)": RandomForestRegressor(500, random_state=0, min_samples_leaf=5)}.items():
    m.fit(Xtr, ytr); p2["models"][name] = m3(yte, m.predict(Xte))
frame = ns["frame"]; r2s = []
for s in range(20):
    a, b = train_test_split(frame, test_size=0.2, random_state=s)
    r2s.append(r2_score(b["target"], LinearRegression().fit(a.drop(columns="target"), a["target"]).predict(b.drop(columns="target"))))
p2["linreg_r2_over_20_seeded_splits"] = {"min": round(min(r2s), 4), "median": round(float(np.median(r2s)), 4), "max": round(max(r2s), 4)}
RESULTS["P2_baselines"] = p2

# ---------------- P3: E2E BYOD matrix through cells 13 -> 23 ----------------
base = ns["frame"].copy()
def csv_bytes(df):
    return df.to_csv(index=False).encode()
cases = {}
good = base.copy(); good.insert(0, "site_id", [f"{i % 7:02d}" for i in range(len(good))])
cases["good_numeric_plus_categorical_id"] = ({"mine.csv": csv_bytes(good)}, ["site_id"])
miss = base.copy(); miss.loc[miss.index[:5], "target"] = np.nan
cases["missing_target_values"] = ({"mine.csv": csv_bytes(miss)}, [])
txt = base.copy(); txt["target"] = txt["target"].astype(object); txt.loc[txt.index[0], "target"] = "abc"
cases["non_numeric_target"] = ({"mine.csv": csv_bytes(txt)}, [])
const = base.copy(); const["target"] = 1.0
cases["constant_target"] = ({"mine.csv": csv_bytes(const)}, [])
inft = base.copy(); inft.loc[inft.index[0], "target"] = np.inf
cases["infinite_target"] = ({"mine.csv": csv_bytes(inft)}, [])
cases["target_declared_categorical"] = ({"mine.csv": csv_bytes(base)}, ["target"])
notarget = base.rename(columns={"target": "progression"})
cases["target_column_named_differently"] = ({"mine.csv": csv_bytes(notarget)}, [])
dup = csv_bytes(base).replace(b"age,sex", b"age,age", 1)
cases["duplicate_columns"] = ({"mine.csv": dup}, [])
cases["declared_categorical_absent"] = ({"mine.csv": csv_bytes(base)}, ["zip_code"])
inf = base.copy(); inf.loc[inf.index[0], "bmi"] = np.inf
cases["infinite_feature"] = ({"mine.csv": csv_bytes(inf)}, [])
tiny = base.head(4).copy()
cases["four_row_table"] = ({"mine.csv": csv_bytes(tiny)}, [])
cases["two_files"] = ({"a.csv": csv_bytes(base), "b.csv": csv_bytes(base)}, [])
p3 = {}
for name, (upload, cats) in cases.items():
    wdc = Path(tempfile.mkdtemp(prefix=f"tdr_byod_{name}_"))
    nsb, st = e2e_run(wdc, byod=upload, categorical=cats)
    last = st[-1]
    rec = {"cells_ok": [s["cell"] for s in st if s["ok"]], "stopped_in_cell": None if last["ok"] else last["cell"], "error": last.get("error")}
    if last["ok"] and "metrics" in nsb:
        rec["reached"] = "export + fresh reload (cell 23)"; rec["holdout_rows_scored"] = len(nsb["test"]); rec["stand_in_metrics"] = nsb["metrics"]
    p3[name] = rec
RESULTS["P3_e2e_byod_matrix"] = p3

# ---------------- P4: re-run journeys in one namespace ----------------
p4 = {}
wd4 = Path(tempfile.mkdtemp(prefix="tdr_rerun_"))
ns4, st = e2e_run(wd4)
art_sha_1 = H.sha256(wd4 / "outputs/artifact/artifact.json")
# repeat cells 13..23 (re-run from Section 4) and the export cell alone
again = [H.run_cell(ns4, E2E_CELLS[i], i) for i in [13, 15, 17, 19, 21, 23]]
p4["rerun_sections_4_to_9_same_kernel"] = {"all_ok": all(s["ok"] for s in again),
    "artifact_json_identical": H.sha256(wd4 / "outputs/artifact/artifact.json") == art_sha_1}
alone = H.run_cell(ns4, E2E_CELLS[23], 23)
p4["rerun_export_cell_alone"] = {"ok": alone["ok"], "error": alone.get("error")}
# BYOD after the default run: switch the form in cell 13 and run from it, in the same kernel
colab = H.Colab(); colab.queue.append({"mine.csv": csv_bytes(good)})
src = H and set_form(set_form(E2E_CELLS[13], "USE_BYOD", True), "CATEGORICAL_COLUMNS", ["site_id"])
st = [H.run_cell(ns4, src, 13)] + [H.run_cell(ns4, E2E_CELLS[i], i) for i in [15, 17, 19, 21, 23]]
H.Colab.remove()
res = json.load(open(wd4 / "outputs/tabdpt_regressor_result.json"))
p4["byod_after_default_same_kernel"] = {"all_ok": all(s["ok"] for s in st), "result_sample_kind": res["sample"]["kind"],
    "artifact_feature_count": len(json.load(open(wd4 / "outputs/artifact/artifact.json"))["preprocessing"]["encoder"]["featureColumns"])}
# outside Colab, USE_BYOD=True has no path field
nsx = fresh_ns(E2E_CELLS, Path(tempfile.mkdtemp(prefix="tdr_nocolab_")))
s = H.run_cell(nsx, set_form(E2E_CELLS[13], "USE_BYOD", True), 13)
p4["byod_outside_colab"] = {"ok": s["ok"], "error": s.get("error")}
RESULTS["P4_rerun_journeys"] = p4

# ---------------- P5: E2E -> companion artifact contract ----------------
ART = E2E_WD / "outputs/artifact"
new_rows = ns["new_rows"]
def ai_run(workdir, artifact_dir="", new_path="", uploads=(), colab=True):
    c = H.Colab() if colab else None
    if c: c.queue.extend(uploads)
    nsa = fresh_ns(AI_CELLS, workdir)
    steps = []
    for i in [13, 15, 17, 19]:
        src = AI_CELLS[i]
        if i == 13: src = set_form(src, "ARTIFACT_DIR", str(artifact_dir))
        if i == 17: src = set_form(src, "NEW_DATA_PATH", str(new_path))
        s = H.run_cell(nsa, src, i); steps.append(s)
        if not s["ok"]: break
    if c: H.Colab.remove()
    last = steps[-1]
    return nsa, {"cells_ok": [s["cell"] for s in steps if s["ok"]], "stopped_in_cell": None if last["ok"] else last["cell"], "error": last.get("error")}

p5 = {}
wd5 = Path(tempfile.mkdtemp(prefix="tdr_ai_"))
unl = wd5 / "new_rows.csv"; new_rows.to_csv(unl, index=False)
nsa, r = ai_run(wd5, ART, unl)
if r["stopped_in_cell"] is None:
    pe = pd.read_csv(E2E_WD / "outputs/tabdpt_regressor_predictions.csv")
    pa = pd.read_csv(wd5 / "outputs/tabdpt_regressor_artifact_inference_predictions.csv")
    r["companion_predictions_equal_e2e"] = bool(np.allclose(pe["prediction"], pa["prediction"], rtol=1e-5, atol=1e-6))
    r["row_id_e2e"] = pe["row_id"].tolist(); r["row_id_companion"] = pa["row_id"].tolist()
    r["evaluation_report_sample_kind"] = nsa["report"]["sample_kind"]
    r["outputs"] = sorted(os.listdir(wd5 / "outputs"))
p5["e2e_artifact_plus_unlabelled_rows"] = r
# the E2E notebook writes no unlabelled input; its predictions CSV is the nearest file
p5["e2e_predictions_csv_as_new_input"] = ai_run(Path(tempfile.mkdtemp()), ART, E2E_WD / "outputs/tabdpt_regressor_predictions.csv")[1]
p5["artifact_dir_set_new_data_by_upload"] = ai_run(Path(tempfile.mkdtemp()), ART, "", uploads=[{"new_rows.csv": unl.read_bytes()}])[1]
p5["default_both_empty_outside_colab"] = ai_run(Path(tempfile.mkdtemp()), "", "", colab=False)[1]
p5["default_both_empty_colab_nothing_supplied"] = ai_run(Path(tempfile.mkdtemp()), "", "")[1]
p5["upload_only_artifact_json"] = ai_run(Path(tempfile.mkdtemp()), "", "", uploads=[{"artifact.json": (ART / "artifact.json").read_bytes()}])[1]
p5["artifact_dir_missing"] = ai_run(Path(tempfile.mkdtemp()), "/nonexistent/artifact", unl)[1]
def mutate(fn):
    d = Path(tempfile.mkdtemp()) / "art"; shutil.copytree(ART, d); fn(d); return d
p5["tampered_parquet"] = ai_run(Path(tempfile.mkdtemp()), mutate(lambda d: (d / "training_context.parquet").write_bytes((d / "training_context.parquet").read_bytes() + b"x")), unl)[1]
def wrong_rev(d):
    m = json.loads((d / "artifact.json").read_text()); m["baseModel"]["revision"] = "0" * 40; (d / "artifact.json").write_text(json.dumps(m))
p5["base_model_revision_changed"] = ai_run(Path(tempfile.mkdtemp()), mutate(wrong_rev), unl)[1]
def relabel(d):
    # consistent re-signing: change support labels, rewrite parquet, recompute size + sha in the manifest
    ctx = pd.read_parquet(d / "training_context.parquet"); ctx["target"] = 400.0 - ctx["target"]
    ctx.to_parquet(d / "training_context.parquet", index=False)
    m = json.loads((d / "artifact.json").read_text())
    m["trainingContext"]["size"] = (d / "training_context.parquet").stat().st_size
    m["trainingContext"]["sha256"] = H.sha256(d / "training_context.parquet"); (d / "artifact.json").write_text(json.dumps(m))
nsr, rr = ai_run(Path(tempfile.mkdtemp()), mutate(relabel), unl)
if rr["stopped_in_cell"] is None:
    e = pd.read_csv(E2E_WD / "outputs/tabdpt_regressor_predictions.csv")["prediction"].to_numpy(); c = nsr["results"]["prediction"].to_numpy()
    rr["e2e_predictions"] = [round(x, 1) for x in e]; rr["tampered_predictions"] = [round(x, 1) for x in c]
p5["support_target_reflected_and_manifest_rehashed"] = rr
def legacy(d):
    m = json.loads((d / "artifact.json").read_text())
    for k in ("formatVersion", "artifactSemantics"): m.pop(k, None)
    m["preprocessing"].pop("upstream", None); (d / "artifact.json").write_text(json.dumps(m))
p5["legacy_manifest_without_fitted_state"] = ai_run(Path(tempfile.mkdtemp()), mutate(legacy), unl)[1]
extra = new_rows.copy(); extra["patient_id"] = range(len(extra)); ep = wd5 / "with_id.csv"; extra.to_csv(ep, index=False)
p5["new_rows_with_identifier_column"] = ai_run(Path(tempfile.mkdtemp()), ART, ep)[1]
bad = new_rows.copy(); bad["age"] = bad["age"].astype(object); bad.iloc[0, 0] = "abc"; bp = wd5 / "bad.csv"; bad.to_csv(bp, index=False)
p5["non_numeric_value"] = ai_run(Path(tempfile.mkdtemp()), ART, bp)[1]
nap = wd5 / "na_token.csv"; nab = new_rows.copy(); nab["age"] = nab["age"].astype(object); nab.iloc[0, 0] = "n/a"; nab.to_csv(nap, index=False)
nsn, rn = ai_run(Path(tempfile.mkdtemp()), ART, nap)
rn["input_manifest_missing_value_columns"] = nsn.get("input_manifest", {}).get("inputs", [{}])[0].get("missing_value_columns")
p5["na_token_in_numeric_column"] = rn
RESULTS["P5_artifact_contract"] = p5

# ---------------- P6: install guard with a preloaded distribution ----------------
import importlib.metadata as md, subprocess as sp
src3 = E2E_CELLS[3]
nsg = {"__name__": "__guard__"}
real_run, real_ver, real_pd = sp.run, md.version, md.packages_distributions
state = {"installed": False}
sp.run = lambda *a, **k: state.update(installed=True)
md.version = lambda d: ("2.3.0" if state["installed"] else "2.1.3") if d == "numpy" else real_ver(d)
import numpy  # loaded in this interpreter, as Colab loads it before the first cell
try:
    g = H.run_cell(nsg, src3.split("\nimport torch, numpy")[0], 3)
finally:
    sp.run, md.version = real_run, real_ver
RESULTS["P6_install_guard_preloaded_numpy"] = {"simulated": "numpy loaded=2.1.3 (the value Colab T4 reported on 2026-09-27 in bart-mnli-zero-shot-classification-pipeline), pin numpy==2.3.0; pip call replaced by a no-op", "ok": g["ok"], "error": g.get("error")}

# ---------------- P7: static checks ----------------
p7 = {}
for label, nb_path, (cells, nb) in (("e2e", E2E, (E2E_CELLS, e2e_nb)), ("companion", AI, (AI_CELLS, ai_nb))):
    md_text = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    p7[label] = {
        "cells": len(nb["cells"]), "code_cells": len(cells),
        "carried_lines": sum(len(nb["cells"][i]["source"]) for i in CARRIED),
        "declared": nb["metadata"]["dimer"],
        "guided_markers": {k: (k.lower() in md_text.lower()) for k in ["How to use", "Roadmap", "Glossary", "Predict", "What to notice", "Check your", "Troubleshoot", "Infrastructure", "Expected result", "conclusion"]},
        "cellView_form_cells": sum(1 for c in nb["cells"] if c.get("metadata", {}).get("cellView") == "form"),
        "restart_instruction_present": "Restart the runtime" in "".join(cells.values()),
        "google_colab_imports": [i for i, s in cells.items() if "google.colab" in s],
    }
RESULTS["P7_static"] = p7

text = json.dumps(RESULTS, indent=2, default=str)
text = text.replace(tempfile.gettempdir(), "<tmp>")
(OUT / "results.json").write_text(text)
print(text[:200]); print("written", OUT / "results.json")
